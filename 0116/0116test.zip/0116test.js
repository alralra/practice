var x = 5;
var y = 3;
var z = x + y;
console.log(z);
//8

var x = 10;
var y = 5;
var z = x - y;
console.log(z);
//5

var x = 2;
var y = 5;
var z = x * y;
console.log(z);
//10

var x = 5;
var y = 2;
var z = x / y;
console.log(z);
//2.5

var x = 15;
var y = 4;
var z = x % y;
//3
console.log(z);

var x = 5;
var y = ++x;
console.log(y);
//6

var x = 5;
var y = --x;
console.log(y);
//4

var st1 = "자바스크립트";
var st2 = "첫 번째 실습";
var st3 = st1 + st2;
console.log(st3);

var x = "hello";
var y = 123;
var z = x + y;
console.log(z);

var st1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var st2 = st1.length;
console.log(st2);

var str1 = "Hello, Java";
var str2 = str1.replace("Java", "JavaScript");
console.log(str2);

console.log("hello, javascript!".toUpperCase());

console.log("HELLO, JAVASCRIPT!".toLowerCase());

var str = "a,b,c,d,e";
console.log(str[2]);






